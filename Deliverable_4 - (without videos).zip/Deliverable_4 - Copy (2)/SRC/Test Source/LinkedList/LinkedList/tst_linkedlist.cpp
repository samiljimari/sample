#include <QtTest/QtTest>
#include <QtTest>
#include <iostream>

using namespace std;

#include <vector>

// add necessary includes here

class LinkedListTest : public QObject
{
    Q_OBJECT

public:
    int getCount();
    void push();



private slots:
    void test_case1();

};


struct node{
    int data;
    node* next;
};




void push(struct node** head_ref, int new_data)
{
    /* allocate node */
    struct node* new_node =
            (struct node*) malloc(sizeof(struct node));

    /* put in the data  */
    new_node->data  = new_data;

    /* link the old list off the new node */
    new_node->next = (*head_ref);

    /* move the head to point to the new node */
    (*head_ref)=new_node;
}




int getCount(node* head)
{
    int count = 0; // Initialize count
    node* current = head; // Initialize current
    while (current != NULL)
    {
        count++;
        current = current->next;
    }
    return count;
}





void LinkedListTest::test_case1()
{
    node* first;
    node* n;
    node* t;

    node* x;
    // node* current;
    //node* last;

    //node* head= NULL;
     //node* current = head;

    node* head= NULL;


    vector <int> v = {7, 6, 15, 8, 20};

    for (int i = 0; i < v.size(); i++)
    {
        int x = v[i];
        n = new node;
        n->data = x;


        if (i > 0)
        {
            t->next = n;

        }

        t = n;

        if (i == 0)
        {
            first = n;


        }


        }
    ::push(&head,7);
    ::push(&head,6);
    ::push(&head,15);
    ::push(&head,8);
    ::push(&head,20);


        QCOMPARE(::getCount(head), 5);

}


QTEST_APPLESS_MAIN(LinkedListTest)
#include "tst_linkedlist.moc"


