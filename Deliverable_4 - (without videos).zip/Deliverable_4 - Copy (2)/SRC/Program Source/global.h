#ifndef GLOBAL_H
#define GLOBAL_H
#include <Qt>
#include <QGraphicsItem>

extern QString txtFileStorage;
extern QGraphicsItem* coordItem;

#endif // GLOBAL_H
