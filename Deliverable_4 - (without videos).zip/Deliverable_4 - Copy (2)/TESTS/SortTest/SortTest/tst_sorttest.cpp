#include <QtTest>
using namespace std;

#include <vector>
// add necessary includes here

class SortTest : public QObject
{
    Q_OBJECT

public:
    SortTest();
    ~SortTest();

private slots:
    void test_case1();

};

SortTest::SortTest()
{

}

SortTest::~SortTest()
{

}


struct node{
    int data;
    node* next;
};


void SortTest::test_case1()
{
    node* first;
    node* n;
    node* t;
    // node* current;
    node* last;


    //node* current = head;


    int count = 0; // Initialize count



    vector <int> v = {7, 6, 15, 8, 20};

    for (int i = 0; i < v.size(); i++)
    {
        int x = v[i];
        n = new node;
        n->data = x;


        if (i > 0)
        {
            t->next = n;
        }

        t = n;

        if (i == 0)
        {
            first = n;
        }


        }

    // SORT VECTOR FROM LOWEST TO HIGHEST

    sort(v.begin(), v.end());

    vector <int> LowToHigh = {6, 7, 8, 15, 20};


    // COMPARE IF SORTED VECTOR IS LOWEST TO HIGHEST
    QCOMPARE(LowToHigh,v);

}

QTEST_APPLESS_MAIN(SortTest)

#include "tst_sorttest.moc"
