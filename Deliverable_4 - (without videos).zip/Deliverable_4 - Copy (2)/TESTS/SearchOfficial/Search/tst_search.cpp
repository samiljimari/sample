#include <QtTest>
#include <iostream>

using namespace std;

#include <vector>
// add necessary includes here

class Search : public QObject
{
    Q_OBJECT

public:
    Search();
    ~Search();

private slots:
    void test_case1();

};

Search::Search()
{

}

Search::~Search()
{

}

struct node{
    int data;
    node* next;
};


void push(node** head_ref, int new_data)
{

    // allocate node
    node* new_node = new node();

    // put in the data in the new node
    new_node->data = new_data;

    // link the old list
    // off the new node
    new_node->next = (*head_ref);

    // move the head to point
    // to the new node
    (*head_ref) = new_node;
}




int GetNth(node* head, int index)
{

    node* current = head;

    // the index of the
    // node we're currently
    // looking at
    int count = 0;
    while (current != NULL)
    {
        if (count == index)
            return(current->data);
        count++;
        current = current->next;
    }

    /* if we get to this line,
    the caller was asking
    for a non-existent element
    so we assert fail */
    assert(0);
}

void Search::test_case1()
{
    node* first;
    node* n;
    node* t;
    // node* current;
    node* last;


    //node* current = head;


    int count = 0; // Initialize count



    vector <int> v = {7, 6, 15, 8, 20};

    for (int i = 0; i < v.size(); i++)
    {
        int x = v[i];
        n = new node;
        n->data = x;


        if (i > 0)
        {
            t->next = n;
        }

        t = n;

        if (i == 0)
        {
            first = n;
        }


        }

   node* head= NULL;

    push(&head, 7);
    push(&head, 6);
    push(&head, 15);
    push(&head, 8);
    push(&head, 20);

    QCOMPARE(GetNth(head, 3), 6);


}

QTEST_APPLESS_MAIN(Search)

#include "tst_search.moc"
