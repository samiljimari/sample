folder with GUI
